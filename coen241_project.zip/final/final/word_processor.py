from collections import Counter
import numpy as np
import matplotlib.pyplot as plt
import json
from wordcloud import WordCloud

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

global_arr = []
stop_words = stopwords.words('english')
stop_words.append('search')
stop_words.append('says')
#open each .json file and retrieve data
def retrieve_data(file_location):
    f = open(file_location)
    data = json.load(f)
    for entry in data:
        word_array = entry['title'].lower().split(" ")
        filtered_words = [word for word in word_array if word not in stop_words ]
        print(filtered_words)
        global_arr.extend(filtered_words)

retrieve_data('huffpost.json')
retrieve_data('time.json')
retrieve_data('cnn.json')
retrieve_data('fox.json')
retrieve_data('nbc.json')


#generate the word cloud
unique_string=(" ").join(global_arr)
wordcloud = WordCloud(width = 1000, height = 500).generate(unique_string)
plt.figure(figsize=(15,8))
plt.imshow(wordcloud)
plt.axis("off")
plt.savefig("your_file_name"+".png", bbox_inches='tight')
plt.show()
plt.close()

#generate the word frequency graphics
#counts = Counter(global_arr)
counts = dict(Counter(global_arr).most_common(20))
colors = ['tab:blue','tab:orange','tab:green','tab:red','tab:purple', 'tab:pink', 'tab:olive', 'tab:cyan', 'tab:brown', 'tab:gray']
labels, values = zip(*counts.items())

# sort your values in descending order
indSort = np.argsort(values)

# rearrange your data
labels = np.array(labels)[indSort]
values = np.array(values)[indSort]

indexes = np.arange(len(labels))

bar_width = 0
print(labels)
print(values)
plt.barh(indexes, values, align="center", color=colors)

# add labels
plt.yticks(indexes + bar_width, labels)
plt.title("News Headline Word Frequency")
plt.xlabel("# Of Occurances")
plt.ylabel("Word")

plt.show()
